define  KEYHELP         "examples$lib/scr/impix.key"
define  DISPCMD		"display %s %d >& dev$null"

define	SZ_NAME		16			# allow some elbow room

# enumerate the colon commands
define	COMMANDS	"|eparam|peakup|localmin|replace|constant|boxsize"
define	EPARAM		1
define	PEAKUP		2
define	LOCALMIN	3
define	REPLACE		4
define	CONSTANT	5
define	BOXSIZE		6

# enumerate the minimum match choices for the replacement algorithm
define	RALGORITHMS	"|constant|mean|median"
define	RCONSTANT	1
define	RMEAN		2
define	RMEDIAN		3

# data structure representing the current parameters

define	LEN_IP		(8 + SZ_NAME*SZ_CHAR/SZ_STRUCT + 1)

define	IP_IM		Memi[$1]
define	IP_PEAKUP	Memi[$1+1]
define	IP_LOCALMIN	Memi[$1+2]
define	IP_RALG		Memi[$1+3]
define	IP_CONSTANT	Memr[$1+4]
define	IP_BOXSIZE	Memi[$1+5]
define	IP_HALFBOX	Memi[$1+6]
define	IP_FRAME	Memi[$1+7]
define	IP_REPLACE	Memc[P2C($1+8)]
